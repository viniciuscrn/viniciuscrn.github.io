//Dados dos Empregados

const empregados = [
    { nome: "Alice Silva", idade: 28, cargo: "Desenvolvedora", salario: 3500, cidade: "São Paulo", estado: "SP" },
    { nome: "Bruno Pereira", idade: 34, cargo: "Gerente", salario: 7200, cidade: "Rio de Janeiro", estado: "RJ" },
    { nome: "Carlos Almeida", idade: 30, cargo: "Analista", salario: 5200, cidade: "Belo Horizonte", estado: "MG" },
    { nome: "Diana Costa", idade: 25, cargo: "Suporte", salario: 3200, cidade: "Curitiba", estado: "PR" },
    { nome: "Eduardo Nunes", idade: 38, cargo: "Gerente", salario: 8000, cidade: "Porto Alegre", estado: "RS" },
    { nome: "Fernanda Souza", idade: 29, cargo: "Desenvolvedora", salario: 3600, cidade: "Salvador", estado: "BA" },
    { nome: "Gustavo Moreira", idade: 45, cargo: "Diretor", salario: 15000, cidade: "Fortaleza", estado: "CE" },
    { nome: "Helena Figueira", idade: 32, cargo: "Analista", salario: 5000, cidade: "Manaus", estado: "AM" },
    { nome: "Igor Martins", idade: 27, cargo: "Suporte", salario: 3100, cidade: "Recife", estado: "PE" },
    { nome: "Julia Ramos", idade: 31, cargo: "Desenvolvedora", salario: 3700, cidade: "Brasília", estado: "DF" },
    { nome: "Lucas Oliveira", idade: 33, cargo: "Suporte", salario: 3300, cidade: "Natal", estado: "RN" },
    { nome: "Mariana Cunha", idade: 29, cargo: "Analista", salario: 4900, cidade: "Vitória", estado: "ES" },
    { nome: "Nina Araújo", idade: 26, cargo: "Desenvolvedora", salario: 3400, cidade: "Florianópolis", estado: "SC" },
    { nome: "Otávio Fernandes", idade: 42, cargo: "Gerente", salario: 7500, cidade: "Goiânia", estado: "GO" },
    { nome: "Paula Dias", idade: 24, cargo: "Suporte", salario: 3100, cidade: "Belém", estado: "PA" },
    { nome: "Quintino Batista", idade: 37, cargo: "Diretor", salario: 14500, cidade: "São Luís", estado: "MA" },
    { nome: "Renata Lima", idade: 35, cargo: "Analista", salario: 5300, cidade: "Teresina", estado: "PI" },
    { nome: "Silvia Mendes", idade: 30, cargo: "Desenvolvedora", salario: 3650, cidade: "Campo Grande", estado: "MS" },
    { nome: "Thiago Cavalcanti", idade: 41, cargo: "Gerente", salario: 8200, cidade: "Aracaju", estado: "SE" },
    { nome: "Ursula Rocha", idade: 28, cargo: "Suporte", salario: 3200, cidade: "Maceió", estado: "AL" }
];
